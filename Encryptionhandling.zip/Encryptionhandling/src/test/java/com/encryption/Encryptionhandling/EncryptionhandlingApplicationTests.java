package com.encryption.Encryptionhandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncryptionhandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
